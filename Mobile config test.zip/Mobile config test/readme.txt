                                                                                            Description

                                                           An .aspx file that can succesfully detect whether you are using a desktop or mobile device
==============================================================================================================================================================================
                                                                                            How It Works

                          There are two labels within the .aspx file that can be toggled through the (request.browser.ismobiledevice == true) condition. 
                                                    If the condition is true then Label 1 will be set to invisible and label 2 will re-appear

                                                                       If the condition is false then the opossite will happen
==============================================================================================================================================================================